def maximize_tree(t):
    """ Changes the label of a node to the maximum label found
    in its siblings, if this increases the value of the label of the node.
    If a node has no siblings or the maximum label found in its siblings
    is less than its original label, its label should not change. Assume 
    that all labels are nonnegative integers.
    """
    [____________________________________________________________]
    orig = ______________________________________________________
    for i in range(______________________________________________):
        ls = ____________________________________________________
        for j in ________________________________________________:
            if __________________________________________________:
                _________________________________________________:
        _________________________________________________________
