"""" CSM 61A Week 2 Fall 2020 """

###########
# Control #
###########

"""
1. Write a function that returns true if a number is divisible by 4 and false otherwise.
"""
def is_divisible_by_4(num):
	## YOUR CODE HERE ##

"""
2. Write a function is_leap_year that returns true if a number is a leap year and false otherwise.
A leap year is a year that is divisible by 4 but not divisible by 400.
"""
def is_leap_year(year):
	## YOUR CODE HERE ##


"""
Write a function find_max that will take in 3 numbers, x, y, z, and return the max value. 
Assume that x, y, and z are unique. Do not use Python's built-in max function.
"""
def find_max(x, y, z):
	## YOUR CODE HERE ##